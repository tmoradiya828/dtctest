﻿=== Ultimate Addons for Contact Form 7 ===
Contributors: themefic, raihan143, hasanet
Tags: contact form 7, contact form 7 addons, contact form 7 addon, contact form 7 booking form, contact form 7 appointment form, contact form 7 placeholder, contact form 7 conditional fields, redirection for contact form 7, contact form 7 thank you page, contact form 7 columns, contact form 7 style, contact form 7 woocommerce, contact form 7 woocommerce product, multi step contact form 7, multi-step contact form, multi step form, post submission contact form 7, form to post contact form 7, contact form 7 to post, custom post contact form 7, contact form 7 custom post type, contact form 7 post submit, caldera forms, Star Rating, Star Rating contact form 7, range slider, range slider contact form 7, contact form 7 conditional redirect, contact form 7 column width, contact form 7 repeater, contact form 7 repeatable fields
Requires at least: 4.2
Tested up to: 5.9
Requires PHP: 5.4
Stable tag: 1.8.8
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

The Ultimate plugin you should install after Contact form 7! Packed with 15+ stunning Contact form 7 including Contact form 7 Placeholder Style, External url Redirection for contact form 7, Contact form 7 Conditional Fields, Contact form 7 columns / Grid Layout, Contact form 7 WooCommerce Product Dropdown Field, Multi Step Contact Form 7, Contact Form 7 Post Submission, Contact Form 7 Star Rating Fields, Contact Form 7 Range Slider and many more stunning features, all in one.

== Description ==

= The easiest and best Contact Form 7 Addons Plugin for WordPress =

The Ultimate plugin you should install after Contact form 7! Packed with 15+ stunning Contact form 7 including Contact form 7 Placeholder Style, External url Redirection for contact form 7, Contact form 7 Conditional Fields, Contact form 7 columns / Grid Layout, Contact form 7 WooCommerce Product Dropdown Field, Multi Step Contact Form 7, Contact Form 7 Post Submission, Contact Form 7 Star Rating Fields, Contact Form 7 Range Slider and many more stunning features, all in one.

👉 Official Demo Link: [Live Preview](https://cf7addons.com/)
👉 Documentation: [Written Installation Guide](https://themefic.com/docs/ultimate-addons-for-contact-form-7)
👉 Join Our FB Community: [Facebook Group](https://facebook.com/groups/ultimate.cf7)
👉 Video Guide: [Youtube Video](https://www.youtube.com/playlist?list=PLY0rtvOwg0ylGspzo7TcT-8x0FH_O5XVV)

= The Fastest Growing Contact Form 7 Addons Plugin  =

<strong>Ultimate Addons For Contact Form 7</strong> can enhance features of your Website's Form developed with <a href="https://wordpress.org/plugins/contact-form-7/">Contact Form 7</a>. This All-in-One Contact form 7 addon plugin has all the basic to advanced options which you may need for your Contact Form. Redirection, Conditional Fields, Placeholder styling, Columns Layout, Multistep form building, WooCommerce Integration, Form Styling, Custom css, Contact Form 7 to Post or Custom Post Type and many more!

<strong>Demo Link </strong>
> <strong><a href="https://cf7addons.com" target="_blank">Check out the demo</a></strong> to see it in action!

> We believe the free version is good enough for most business. However, we have a **Pro version** of this plugin which has more advanced features including **Frontend post submission with Contact form 7, Contact form 7 WooCommerce Checkout, Show Specific WooCommerce Product as Dropdown, Choose Multiple WooCommerce Product, Show Product based on Category** and many more.

### How It works:
<iframe width="560" height="315" src="https://www.youtube.com/embed/mxcC1eQXxEI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

**How to create a Multi-Step form with Contact Form 7**

[youtube https://www.youtube.com/watch?v=7Ucrx_ttGdM]

<br>

**How to style your Contact Form 7 Form without CSS/Coding**

[youtube https://www.youtube.com/watch?v=X7M2Wj5cd-s]
<br>

**How to add Star Rating Feedback in Contact Form 7**

[youtube https://www.youtube.com/watch?v=Q5AN9lp2HcY]

Want to know all the latest news and be a part of the CF7 Ultimate Addons community? Join our <a href="https://facebook.com/groups/ultimate.cf7" target="_blank">Facebook Community group!</a>

<hr>

### Features:

Here are the most important features of Ultimate Addons For Contact Form 7:

= Contact Form 7 Conditional Fields = 

Add conditional logic to Contact Form 7. With this feature, you can show or hide form fields depending on Contact form 7 Conditional Logic. <a href="https://cf7addons.com/preview/conditional-field/">Click Here</a> to check live preview.

= Contact Form 7 Placeholder = 

With this feature, you can edit contact form 7 placeholder text color, placeholder text background color, placeholder text font size, font family, font style and font weight. In short, you can edit the style of your form's placeholder without writing any css code. <a href="https://cf7addons.com/preview/placeholder-styling/">Click Here</a> to check live preview.

= Contact Form 7 Columns / Grid Layout =
You can easily create two columns, three Columns; even Four columns form with Contact form 7 using this feature. Fully responsive. <a href="https://cf7addons.com/preview/columns-grid-layout/">Click Here</a> to check live preview.

= Multi step contact form 7 = 

You can easily create multistep form with Contact form 7 using this feature. Fully responsive. <a href="https://cf7addons.com/preview/multi-step-form/">Click Here</a> to check live preview.

= Redirection for Contact Form 7 = 

This features will help you to redirect contact form 7 after submission. You can Redirect users to a Thank you page or external page after user fills up Form. Rredirect user to any page you choose after mail sent successfully. <a href="https://cf7addons.com/preview/redirection/">Click Here</a> to check live preview.

= Contact Form 7 Star Rating Field = 

Add Star Rating fields to Contact Form 7. Star rating is the easiest and efficient way to get feedback from your customers on how good your product or service is. Good news! Now you can easily add a star rating to your Contact form 7, using Ultimate Addons for Contact form 7, within minutes. <a href="https://cf7addons.com/preview/star-rating/">Click Here</a> to check live preview.

= Contact Form 7 Range Slider = 

Add Range slider fields to Contact Form 7. Ultimate Addon's Range Slider for Contact form 7 helps you to easily setup field range in your contact form 7 for your WordPress site. <a href="https://cf7addons.com/preview/range-slider/">Click Here</a> to check live preview.

= Contact form 7 WooCommerce Product = 

This features will help you to add WooCommerce Product Dropdown field on Contact Form 7. You can add all your product as a dropdown on your form, when user submits, you will get the data on your email. With this, your customer can easily do WooCommerce Product Enquiry with contact form 7. Note that, with free version you can add all products. If you need to add specific products and other options, check the features on Pro. <a href="https://cf7addons.com/preview/woocommerce/">Click Here</a> to check live preview.

= Contact form 7 Style = 

This features will help you to edit the following: Contact form 7 label color, label Background color, label font style, label font size, label font weight, label  font family, label padding, label margin; Contact Form 7 Input Color, Input Background Color, Input Font Style, Input Font Weight, Input Font Size, Input Font Family, Input Height, Input Padding, Input Margin; Contact form 7 button style, Contact form 7 button color, button background color, button font size, button font weight, button width, button border styles, button padding, button margin, Contact form 7 font size etc. <a href="https://cf7addons.com/preview/form-styling/">Click Here</a> to check live preview.

= Contact form 7 Custom css = 

This features will help you to add your own custom css for Contact Form 7.

= More Addons Coming Soon =

Each month we have targets to introduce atleast 1 new Addons.

> <strong><a href="https://cf7addons.com" target="_blank">Check out the demo</a></strong>

<hr>

### Pro Features

There is also a pro version of this plugin. You will get more features and advantages on the pro version. Here are few feature of the Pro Version:

= All Free Features =

The Pro version includes all the free features.

= Conditional Redirection for Contact Form 7 = 

This features will help you to redirect user to a specific page after submission based on condition. For example, if an user selects "Yes" from dropdown, they will be redirected to a Specific page, if they select "No", they will be redirected to another page. In short this is the Ultimate Conditional Redirect for Contact Form 7. <a href="https://cf7addons.com/preview/conditional-redirect/">Click Here</a> to check live preview.

= Custom Column Width for Contact Form 7 = 

This features will help you to set the column of your form at your desired width. You can set any size of column. For example, you can create two columns form with one column width of 12% and other 88% and so on. <a href="https://cf7addons.com/preview/custom-columns-grid-layout/">Click Here</a> to check live preview.

= Contact form 7 Repeater = 

This features will help you to add Repeatable Fields to Contact Form 7. You can add all kinds of fields from text, files, checkboxes, radio buttons, textarea etc. <a href="https://cf7addons.com/preview/repeater-field/">Click Here</a> to check live preview.

= Contact Form 7 Booking Form / Appointment Form = 

This features will help you to create a booking form / Appointment Form using Contact Form 7. You can insert Calendar, Time on the form and manage your booking. <a href="https://cf7addons.com/preview/booking-form/">Click Here</a> to check live preview.

= Contact form 7 WooCommerce Checkout =

Ultimate Addons for Contact form 7 Pro version gives you the power to add WooCommerce Checkout to your Contact form 7 forms. Once customer choose your product and submits the form, they will be redirected to the cart page with the product added to the cart. They can then proceed to checkout and complete WooCommerce Payment. However, note that, this option is not applicable to variable and grouped product (We are looking for a solution to add this in future versions). <a href="https://cf7addons.com/preview/woocommerce-checkout/">Click Here</a> to check live preview.

= Contact form 7 Frontend Post Submission =

Create a post submission form with Contact Form 7. Each forms submitted from your website will be published as a new post which you can manage in your dashboard and display on the front end. You can add title, description, category, featured image by default. With the power of "Custom Field", you can connect with any custom field with this form. <a href="https://cf7addons.com/preview/post-submission/">Click Here</a> to check live preview.

= Contact form 7 to custom post type =

Easily process a contact form from contact form 7 into a custom post type. <a href="https://cf7addons.com/preview/post-submission/">Click Here</a> to check live preview.

= Contact Form 7 Star Rating Field (Pro) =

While the free version has 1 Star Field, with Pro, you will get 5 Built in Rating Styles. If you don't like them, no worries. The pro version gives you the ability to add any icon from Font Awesome and add them. <a href="https://cf7addons.com/preview/star-rating-pro/">Click Here</a> to check live preview.

= Choose Specific WooCommerce Product =

The pro version gives you the ability to add specific WooCommerce Product Dropdown on your Contact Form 7 forms. You can add the Products based on Product ID. <a href="https://cf7addons.com/preview/woocommerce-product-dropdown/">Click Here</a> to check live preview.

= Choose Multiple WooCommerce Product =

Want the ability to let your customer choose Multiple WooCommerce Product on your Contact Form 7 forms? Good news, this is also available on our Pro version. <a href="https://cf7addons.com/preview/multiple-product/">Click Here</a> to check live preview.

= Contact form 7 Categorize WooCommerce Product =

With Pro, you can also show product based on WooCommerce Category. <a href="https://cf7addons.com/preview/categorized-product/">Click Here</a> to check live preview.

= Multi-step Button Editing =

This features will help you edit the button text and add image on background on the Multi-step form.

= More Addons Coming Soon =

Each month we have targets to introduce atleast 1 new Addons.

> <strong><a href="https://cf7addons.com/pricing" target="_blank">Buy Pro Version</a></strong>

<hr>

<strong>Premium Support</strong>

We provide full support on the WordPress.org forums. You can also post questions or bug reports through our <a href="https://facebook.com/groups/ultimate.cf7" target="_blank">Facebook group</a> or <a href="https://themefic.com/contact/">our website</a>. However, please note that, for free version's support/replies, there can be delays upto 24-48 hours. So, if you need urgent support, we recommend purchasing <strong><a href="https://cf7addons.com/pricing" target="_blank">Pro Version</a></strong>.

<strong>Privacy Policy : </strong>

This plugin doesn’t collect/store any user related information.

<strong>Our Other Plugins</strong>

* <a href="https://wordpress.org/plugins/instantio" target="_blank">Onepage / Direct Checkout for WooCommerce - Instantio</a>
* <a href="https://wordpress.org/plugins/tourfic/">Tourfic – Travel Booking Solution for WooCommerce</a>
* <a href="https://wordpress.org/plugins/wp-guidance-tutorial-for-beginners/">WP Guidance - Guideline/Tutorial for WordPress Beginners</a>
* <a href="https://wordpress.org/plugins/beaf-before-and-after-gallery/">Ultimate Before After Image Slider – BEAF</a>

<strong>Credits</strong>

The icon and banner used on this plugin are taken from <a href="https://www.iconfinder.com" target="_blank">Iconfinder</a> and <a href="https://www.freepik.com/vectors/nature" target="_blank">Freepik</a>

== Installation ==

1. Download and unzip the plugin. Upload the unzipped folder to the wp-contents/plugins folder of your WordPress installation.
2. Active the plugin from the WordPress Plugins administration page.
3. OR, Go to WP admin panel, click 'Plugins' -> 'Add new'. In the search input box, type 'Ultimate Addons for Contact form 7'.
4. Install and activate the plugin.
5. Go to Plugin Settings (Dashboard -> Contact -> Ultimate Addons) and enable the addon you need.

== Frequently Asked Questions ==

= How to create Conditional fields with contact form 7? =

If you want to create cf7 conditional fields, you can easily do it with our Ultimate Addons plugin. Check this <a href="https://youtu.be/mxcC1eQXxEI?t=253">video</a>.

= How to enable contact form 7 redirect to thank you page? =

With our Ultimate addon plugin you can easily configure contact form 7 to redirect after submit. . Check this <a href="https://youtu.be/mxcC1eQXxEI">video</a> to understand how to enable contact form 7 redirect on submit.

= Can this plugin help my contact form redirect after submit? =

Yes, With our Ultimate addon plugin you can easily configure contact form 7 to redirect after submit. Check this <a href="https://youtu.be/mxcC1eQXxEI">video</a> to understand how to enable contact form 7 redirect on submit.

= Can I create two column contact form 7 with this plugin? =

Yes, With our Ultimate addon plugin you can easily configure contact form 7 two columns. Check this <a href="https://youtu.be/mxcC1eQXxEI?t=162">video</a> to understand how to enable contact form 7 2 columns. You can also create three columns contact form 7 form and four columns contact form 7 form.

= How to change Contact Form 7 Placeholder Text Color, font size other styles? =

With our Ultimate addon plugin you can easily edit cf7 placeholder.

= Are there any contact form 7 style plugin available on WordPress? =

Yes. Ultimate Addons For Contact Form 7 will let you edit the styles of your contact form 7 with it's awesome styler addon. You can also do css styles for contact form 7 with this plugin.

= Can I add WooCommerce Product dropdown on Contact form 7? =

Yes. Ultimate Addons For Contact Form 7 will let you add WooCommerce Product dropdown on your CF7 Forms.

= Can I add WooCommerce Product dropdown on Contact form 7? =

Yes. Ultimate Addons For Contact Form 7 will let you add WooCommerce Product dropdown on your CF7 Forms.

= Can I add WooCommerce Order with Contact form 7? =

Yes. Ultimate Addons For Contact Form 7 Pro version has the option to Checkout with WooCommerce after form submission and place order of that product.

= How to do Contact form 7 WooCommerce integration? =

Just install our Plugin.

= How to create a multi step form using Contact Form 7? =

Just install our Plugin. It will only take 5 mins to create a multi-step form using our Plugin. <a href="https://youtu.be/7Ucrx_ttGdM">Check this Step by Step video</a>.

= How to publish a post or custom post using Contact Form 7? =

Just install our Plugin. It will only take 5 mins to create such a form.</a>.

=  =

== Screenshots ==

1. Settings Panel
2. Contact form 7 Columns
3. Contact Form 7 Placeholder Style
4. Contact Form 7 Styles (Label Options)
5. Contact Form 7 Styles (Input Field Options)
6. Contact Form 7 Styles (Submit Button Options)
7. Contact Form 7 Styles (Custom CSS Options)
8. Contact form 7 Conditional Fields
9. Redirection for Contact Form 7
10. WooCommerce Product Dropdown (Free + Pro)
11. WooCommerce Checkout (Pro)
12. Multi-Step Form Backend (Pro)
13. Star Rating Field
14. Repeater Field
15. Custom Column Width (Pro)
16. Frontend Post Submission
17. Conditional Redirect (Pro)
18. Multistep Editor Panel

== Changelog ==

= 1.8.8 - 14/02/2022 =

- Fixed multistep issue

= 1.8.7 - 13/02/2022 =

- Fixed an issue

= 1.8.6 - 10/02/2022 =

- Added multistep new skin

= 1.8.5 - 09/02/2022 =

- Fixed an error

= 1.8.4 - 1/1/2022 =

- Fixed additional bugs

= 1.8.3 - 26/1/2022 =

- Compatiblity Check: WordPress 5.9

= 1.8.2 - 24/1/2022 =

– Fixed range slider issue
- Fixed multistep next button issue

= 1.8.1 - 7/1/2022 =

– Updated: Preview URL of the Plugin
– Compatiblity Check: WordPress 5.8.3

= 1.8.0 - 5/1/2022 =

– Fixed: CF7 Addon Dashboard Major Bug (Updated recommend)
– Introducing: New Pro Addon - Booking/Appointment Form

= 1.7.4 - 2/1/2022 =

– WooCommerce 6.0 Compatiblity Check
– Contact Form 7 5.5.3 Compatiblity Check

= 1.7.3 - 13/12/2021 =

- Added auto-scroll feature with the multistep form
- Added style option for multistep buttons
- Added color to all the Ultimate addons tag generator buttons
- Fixed Field validation issue with conditional field and multistep form
- Fixed additional bugs

= 1.7.2 - 24/11/2021 =

- Fixed an issue

= 1.7.1 - 24/11/2021 =

- Fixed an issue

= 1.7.0 - 15/11/2021 =

- WordPress 5.8.2 Compatiblity
- Contact Form 7 5.5.2 Compatiblity
- Introducing: New Addon - Custom Column Width (Pro)
- Introducing: New Addon - Repeater Field (Pro)

= 1.6.2 - 26/10/2021 =

- Fixed a glitch of Multi Step Form Field
- Introducing: New Addon - Conditional Redirect for Contact Form 7 (Pro)

= 1.6.1 - 21/09/2021 =

- Fixed a glitch of Multi Step Form Field

= 1.6.0 - 12/09/2021 =

– Added Range Slider Field
- Fixed some compatiblity issues with Multi Step Form Field

= 1.5.3 - 02/09/2021 =

– Updated Documentation Tab
– Added Style Fix for Star Rating

= 1.5.2 - 26/08/2021 =

– Added Documentation Tab
– Added Style Fix for Star Rating
- Added Star Rating Pro Support.

= 1.5.1 - 14/08/2021 =

– Added Star Rating Fields
– Added Conditional Logic support for Checkbox and Radio Buttons
- Fixed some compatiblity issues.

= 1.5.0 - 6/08/2021 =

– Fixed some style issues
– Added Frontend Post Submission (Pro)

= 1.4.4 - 29/06/2021 =

– WordPress 5.8 Compatiblity Check
– Contact Form 7 5.4.2 Compatiblity Check

= 1.4.3 - 29/06/2021 =

- Fixed: Columns Last Child Margin Right Issue.

= 1.4.2 - 27/06/2021 =

- Fixed: Multistep Form Style Issue.

= 1.4.1 - 15/06/2021 =

- Fixed: Conflict with Elementor Page Builder.

= 1.4.0 - 14/06/2021 =

- Tested Contact Form 7 version 5.4.1 Compatibility
- Added New Addon: Contact form 7 Multi-step Form
- Fixed Column Addon CSS Issue

= 1.3.0 - 13/05/2021 =

- Tested WP 5.7.2 Compatibility
- Added New Addon: Contact form 7 WooCommerce Product Dropdown
- Added Pro version options

= 1.2.7 - 12/04/2021 =

- Few style improvement

= 1.2.6 - 27/03/2021 =

- Fixed: Padding and margin issue on Column Settings

= 1.2.5 - 20/03/2021 =

- Few style improvement

= 1.2.4 - 12/03/2021 =

- Tested WP 5.7 Compatibility

= 1.2.3 - 10/03/2021 =

- Few minor improvement

= 1.2.2 - 02/03/2021 =

- Few minor improvement

= 1.2.1 - 15/02/2021 =

- Added New Addon: Contact form 7 Styling
- Fixed Style of Placeholder Panel

= 1.1.1 - 13/02/2021 =

- Added New Addon: Contact form 7 Placeholder Styling
- Fixed Minor Issues

= 1.0.3 - 10/02/2021 =

- Fixed Settings panel redirection issue

= 1.0.2 - 08/02/2021 =

- Added WP 5.6.1 Compatibility

= 1.0.1 - 05/02/2021 =

- Few minor improvement

= 1.0.0 - 04/02/2021 =

- Initial stable realese