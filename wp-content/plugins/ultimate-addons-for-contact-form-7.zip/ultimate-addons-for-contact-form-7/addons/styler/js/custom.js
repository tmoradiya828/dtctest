jQuery(document).ready(function($) {
  wp.codeEditor.initialize($('#uacf7-customcss'), cm_settings);
})